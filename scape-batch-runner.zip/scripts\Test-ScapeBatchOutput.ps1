[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$OutputRoot,

    [string]$ReportName = 'validation_report.md',

    [string[]]$SkipDirectory = @(),

    [string[]]$RequiredFiles = @(
        'SED_TRANS_POT_ANN.txt',
        'SED_TRANS_ANN.txt',
        'VOLUME_B_ANN_AVE.txt',
        'CONTOUR_SHORE.txt',
        'CONTOUR_ROCK.txt',
        'log.txt'
    )
)

$ErrorActionPreference = 'Stop'

$experiments = Get-ChildItem -LiteralPath $OutputRoot -Directory |
    Where-Object { $_.Name -notin $SkipDirectory } |
    Sort-Object Name

$findings = New-Object System.Collections.Generic.List[object]

foreach ($experiment in $experiments) {
    $exitPath = Join-Path $experiment.FullName 'run_exitcode.txt'
    $stdoutPath = Join-Path $experiment.FullName 'run_stdout.log'
    $stderrPath = Join-Path $experiment.FullName 'run_stderr.log'

    $exitCode = if (Test-Path -LiteralPath $exitPath) { (Get-Content -LiteralPath $exitPath -ErrorAction SilentlyContinue | Select-Object -First 1) } else { $null }
    if ($exitCode -ne '0') {
        [void]$findings.Add([PSCustomObject]@{
            Name = $experiment.Name
            Type = 'ExitCode'
            Detail = "Expected 0, got $exitCode"
        })
    }

    if ((Test-Path -LiteralPath $stdoutPath) -and (Select-String -LiteralPath $stdoutPath -Pattern '\*\*\* Error' -Quiet)) {
        [void]$findings.Add([PSCustomObject]@{
            Name = $experiment.Name
            Type = 'StdoutError'
            Detail = 'run_stdout.log contains *** Error'
        })
    }

    if ((Test-Path -LiteralPath $stderrPath) -and ((Get-Item -LiteralPath $stderrPath).Length -gt 0)) {
        [void]$findings.Add([PSCustomObject]@{
            Name = $experiment.Name
            Type = 'Stderr'
            Detail = 'run_stderr.log is not empty'
        })
    }

    foreach ($file in $RequiredFiles) {
        $path = Join-Path $experiment.FullName $file
        if (-not (Test-Path -LiteralPath $path) -or ((Get-Item -LiteralPath $path).Length -eq 0)) {
            [void]$findings.Add([PSCustomObject]@{
                Name = $experiment.Name
                Type = 'MissingOrEmpty'
                Detail = $file
            })
        }
    }
}

$findingsPath = Join-Path $OutputRoot 'validation_findings.csv'
$findings | Sort-Object Name, Type, Detail | Export-Csv -LiteralPath $findingsPath -NoTypeInformation -Encoding UTF8

$summaryPath = Join-Path $OutputRoot 'batch_run_summary.csv'
$summary = if (Test-Path -LiteralPath $summaryPath) { Import-Csv -LiteralPath $summaryPath } else { @() }
$durations = @($summary | Where-Object { $_.Seconds } | ForEach-Object { [double]$_.Seconds })
$elapsedPath = Join-Path $OutputRoot 'batch_run_elapsed_minutes.txt'
$elapsed = if (Test-Path -LiteralPath $elapsedPath) { Get-Content -LiteralPath $elapsedPath | Select-Object -First 1 } else { 'unknown' }

$runtimeLine = 'Runtime seconds min/avg/max: n/a'
if ($durations.Count -gt 0) {
    $runtimeLine = "Runtime seconds min/avg/max: $([math]::Round(($durations | Measure-Object -Minimum).Minimum, 1)) / $([math]::Round(($durations | Measure-Object -Average).Average, 1)) / $([math]::Round(($durations | Measure-Object -Maximum).Maximum, 1))"
}

$report = @(
    '# SCAPE batch validation report',
    '',
    "Output root: $OutputRoot",
    "Experiment folders checked: $($experiments.Count)",
    "Total wall-clock minutes: $elapsed",
    "Validation findings: $($findings.Count)",
    $runtimeLine,
    '',
    'Final check result:',
    ($(if ($findings.Count -eq 0) { '- No validation findings.' } else { '- See validation_findings.csv for details.' })),
    '',
    'Required files checked:',
    ($RequiredFiles | ForEach-Object { "- $_" })
)

[System.IO.File]::WriteAllLines((Join-Path $OutputRoot $ReportName), $report, [System.Text.UTF8Encoding]::new($false))

$findings | Sort-Object Name, Type, Detail

