# SCAPE 多组模拟批量运行工作流

## 目标

本项目用于把 SCAPE 的多个实验输入文件夹批量复制到输出目录，并行运行
`RUN_SCAPE.exe`，然后检查每组是否跑通、关键输出是否存在，并生成快速图表。

## 推荐流程

1. 准备输入目录

每个实验一个文件夹，例如：

```text
input/
  ST00_BASE_CONTROL/
  ST10_RIGHT_IN_CLOSED/
  ST11_RIGHT_IN_BASE/
```

如果需要十年快速检查，每个正式实验文件夹内放一个 `_SMOKE_10yr` 子文件夹。

2. 先跑 smoke

```powershell
.\scripts\Run-ScapeBatch.ps1 `
  -InputRoot "...\input" `
  -OutputRoot "...\output\_SMOKE_10yr" `
  -Mode Smoke `
  -MaxParallel 12
```

3. 检查 smoke

```powershell
.\scripts\Test-ScapeBatchOutput.ps1 `
  -OutputRoot "...\output\_SMOKE_10yr" `
  -ReportName "smoke_validation_report.md"
```

4. 再跑正式全周期

```powershell
.\scripts\Run-ScapeBatch.ps1 `
  -InputRoot "...\input" `
  -OutputRoot "...\output" `
  -Mode Formal `
  -MaxParallel 10
```

5. 检查正式输出

```powershell
.\scripts\Test-ScapeBatchOutput.ps1 `
  -OutputRoot "...\output" `
  -ReportName "formal_validation_report.md" `
  -SkipDirectory "_SMOKE_10yr"
```

6. 生成快速图表

```powershell
.\scripts\New-ScapeQuickCharts.ps1 `
  -OutputRoot "...\output" `
  -AnalysisRoot "...\analyse\quick_charts" `
  -Baseline "ST00_BASE_CONTROL" `
  -SkipDirectory "_SMOKE_10yr"
```

## 检查逻辑

`Test-ScapeBatchOutput.ps1` 默认检查：

- `run_exitcode.txt` 是否为 `0`；
- `run_stderr.log` 是否为空；
- `run_stdout.log` 是否包含 `*** Error`；
- 关键输出文件是否存在且非空。

关键输出文件包括：

- `SED_TRANS_POT_ANN.txt`
- `SED_TRANS_ANN.txt`
- `VOLUME_B_ANN_AVE.txt`
- `CONTOUR_SHORE.txt`
- `CONTOUR_ROCK.txt`
- `log.txt`

## 图表逻辑

`scape_quick_charts.py` 读取 SCAPE 常见输出格式：

```text
列数
数值1
数值2
...
```

脚本会把后续数值按第一行列数重构为逐年矩阵，然后计算：

- 潜在输沙总量；
- 实际输沙总量；
- 实际/潜在输沙比；
- 末年平均滩体体积；
- 相对基准的末年平均岸线差值；
- 相对基准的末年平均岩面差值。

