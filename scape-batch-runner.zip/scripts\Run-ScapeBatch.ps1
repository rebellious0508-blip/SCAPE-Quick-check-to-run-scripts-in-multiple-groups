[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$InputRoot,

    [Parameter(Mandatory = $true)]
    [string]$OutputRoot,

    [ValidateSet('Smoke', 'Formal')]
    [string]$Mode = 'Formal',

    [int]$MaxParallel = 4,

    [switch]$Clean
)

$ErrorActionPreference = 'Stop'

function Copy-ExperimentInput {
    param(
        [System.IO.DirectoryInfo]$Experiment,
        [string]$Destination,
        [string]$Mode
    )

    if (Test-Path -LiteralPath $Destination) {
        $existing = Get-ChildItem -LiteralPath $Destination -Force
        if ($existing.Count -gt 0) {
            if ($Clean) {
                Remove-Item -LiteralPath $Destination -Recurse -Force
            } else {
                throw "Output directory is not empty: $Destination. Use -Clean to replace it."
            }
        }
    }

    New-Item -ItemType Directory -Force -Path $Destination | Out-Null

    if ($Mode -eq 'Smoke') {
        $source = Join-Path $Experiment.FullName '_SMOKE_10yr'
        if (-not (Test-Path -LiteralPath (Join-Path $source 'RUN_SCAPE.exe'))) {
            throw "Smoke input missing RUN_SCAPE.exe: $source"
        }
        & robocopy $source $Destination /E /NFL /NDL /NJH /NJS /NP | Out-Null
    } else {
        & robocopy $Experiment.FullName $Destination /E /XD '_SMOKE_10yr' /NFL /NDL /NJH /NJS /NP | Out-Null
    }

    if ($LASTEXITCODE -gt 7) {
        throw "robocopy failed for $($Experiment.Name): $LASTEXITCODE"
    }
}

function Start-ScapeJob {
    param(
        [string]$Name,
        [string]$Directory
    )

    Start-Job -Name $Name -ScriptBlock {
        param($Directory)

        $start = Get-Date
        Set-Location -LiteralPath $Directory
        & '.\RUN_SCAPE.exe' > 'run_stdout.log' 2> 'run_stderr.log'
        $exitCode = $LASTEXITCODE
        $elapsed = [math]::Round(((Get-Date) - $start).TotalSeconds, 1)

        Set-Content -LiteralPath (Join-Path $Directory 'run_exitcode.txt') -Value $exitCode -Encoding ASCII
        Set-Content -LiteralPath (Join-Path $Directory 'run_elapsed_seconds.txt') -Value $elapsed -Encoding ASCII

        [PSCustomObject]@{
            Name     = Split-Path $Directory -Leaf
            ExitCode = $exitCode
            Seconds  = $elapsed
            Dir      = $Directory
        }
    } -ArgumentList $Directory
}

New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

$experiments = Get-ChildItem -LiteralPath $InputRoot -Directory | Sort-Object Name
if ($experiments.Count -eq 0) {
    throw "No experiment directories found in $InputRoot"
}

foreach ($experiment in $experiments) {
    $destination = Join-Path $OutputRoot $experiment.Name
    Copy-ExperimentInput -Experiment $experiment -Destination $destination -Mode $Mode
}

$pending = [System.Collections.Queue]::new()
$experiments | ForEach-Object { $pending.Enqueue($_.Name) }
$jobs = @{}
$results = New-Object System.Collections.Generic.List[object]
$started = 0
$total = $experiments.Count
$overallStart = Get-Date

while ($pending.Count -gt 0 -or $jobs.Count -gt 0) {
    while ($pending.Count -gt 0 -and $jobs.Count -lt $MaxParallel) {
        $name = [string]$pending.Dequeue()
        $directory = Join-Path $OutputRoot $name
        $job = Start-ScapeJob -Name $name -Directory $directory
        $jobs[$job.Id] = $job
        $started++
        Write-Host ("Started {0}/{1}: {2}" -f $started, $total, $name)
    }

    Start-Sleep -Seconds 10

    $done = @($jobs.Values | Where-Object { $_.State -in @('Completed', 'Failed', 'Stopped') })
    foreach ($job in $done) {
        $received = Receive-Job -Job $job -Keep
        if ($received) {
            foreach ($item in $received) {
                [void]$results.Add($item)
                Write-Host ("Completed: {0} exit={1} seconds={2}" -f $item.Name, $item.ExitCode, $item.Seconds)
            }
        }

        if ($job.State -ne 'Completed') {
            $directory = Join-Path $OutputRoot $job.Name
            Set-Content -LiteralPath (Join-Path $directory 'run_job_state.txt') -Value $job.State -Encoding ASCII
            [void]$results.Add([PSCustomObject]@{
                Name     = $job.Name
                ExitCode = $null
                Seconds  = $null
                Dir      = $directory
                JobState = $job.State
            })
            Write-Host ("Job {0} ended state={1}" -f $job.Name, $job.State)
        }

        Remove-Job -Job $job -Force
        $jobs.Remove($job.Id)
    }
}

$summaryPath = Join-Path $OutputRoot 'batch_run_summary.csv'
$results | Sort-Object Name | Export-Csv -LiteralPath $summaryPath -NoTypeInformation -Encoding UTF8

$totalElapsed = [math]::Round(((Get-Date) - $overallStart).TotalMinutes, 2)
Set-Content -LiteralPath (Join-Path $OutputRoot 'batch_run_elapsed_minutes.txt') -Value $totalElapsed -Encoding ASCII

$results | Sort-Object Name | Select-Object Name, ExitCode, Seconds, JobState

