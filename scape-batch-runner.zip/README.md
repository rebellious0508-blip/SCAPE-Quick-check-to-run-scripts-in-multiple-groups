# SCAPE Batch Runner

PowerShell and Python utilities for running many SCAPE simulations in parallel,
checking whether short smoke runs and full-period runs completed correctly, and
building quick diagnostic tables/figures from SCAPE output files.

This project was extracted from the SCAPE sediment-transport experiment workflow:

- run many experiment folders in parallel;
- run `_SMOKE_10yr` folders first to confirm inputs can complete;
- run full-period simulations after smoke validation;
- validate logs and required output files;
- generate quick CSV/SVG charts for sediment-transport diagnostics.

## Project Layout

```text
scape-batch-runner/
  README.md
  LICENSE
  .gitignore
  docs/
    WORKFLOW.zh-CN.md
  examples/
    scape_batch_config.example.json
  scripts/
    Run-ScapeBatch.ps1
    Test-ScapeBatchOutput.ps1
    New-ScapeQuickCharts.ps1
  src/
    scape_quick_charts.py
```

## Quick Start

Run all `_SMOKE_10yr` simulations, 12 at a time:

```powershell
.\scripts\Run-ScapeBatch.ps1 `
  -InputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\input" `
  -OutputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\output\_SMOKE_10yr" `
  -Mode Smoke `
  -MaxParallel 12
```

Validate smoke results:

```powershell
.\scripts\Test-ScapeBatchOutput.ps1 `
  -OutputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\output\_SMOKE_10yr" `
  -ReportName "smoke_validation_report.md"
```

Run full-period simulations, 10 at a time:

```powershell
.\scripts\Run-ScapeBatch.ps1 `
  -InputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\input" `
  -OutputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\output" `
  -Mode Formal `
  -MaxParallel 10
```

Validate full-period results:

```powershell
.\scripts\Test-ScapeBatchOutput.ps1 `
  -OutputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\output" `
  -ReportName "formal_validation_report.md" `
  -SkipDirectory "_SMOKE_10yr"
```

Create quick diagnostic CSV/SVG charts:

```powershell
.\scripts\New-ScapeQuickCharts.ps1 `
  -OutputRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\output" `
  -AnalysisRoot "D:\SCAPE\SCAPE-master\后续实验组输入数据\沉积物运输\analyse\quick_charts" `
  -Baseline "ST00_BASE_CONTROL" `
  -SkipDirectory "_SMOKE_10yr"
```

If `python` is not on `PATH`, pass the interpreter explicitly:

```powershell
.\scripts\New-ScapeQuickCharts.ps1 `
  -OutputRoot "...\output" `
  -AnalysisRoot "...\analyse\quick_charts" `
  -Python "C:\Path\To\python.exe"
```

## Outputs

`Run-ScapeBatch.ps1` writes, for each experiment folder:

- `run_stdout.log`
- `run_stderr.log`
- `run_exitcode.txt`
- `run_elapsed_seconds.txt`

It also writes:

- `batch_run_summary.csv`
- `batch_run_elapsed_minutes.txt`

`Test-ScapeBatchOutput.ps1` writes:

- a Markdown validation report;
- `validation_findings.csv`.

`New-ScapeQuickCharts.ps1` writes:

- `scape_quick_metrics.csv`;
- several `.svg` quick-check charts.

## Notes

- Each SCAPE simulation must run in its own working directory because SCAPE reads
  and writes files relative to the current directory.
- Use smoke runs before long full-period simulations.
- Avoid running all long simulations at once; choose `MaxParallel` based on CPU,
  memory, and disk throughput.
