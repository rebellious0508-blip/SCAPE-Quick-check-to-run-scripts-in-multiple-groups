#!/usr/bin/env python3
"""Build quick CSV/SVG diagnostics for SCAPE batch outputs.

The parser expects the common SCAPE text-output format:

    n_columns
    value_1
    value_2
    ...

Values are reconstructed into rows of n_columns values.
"""

from __future__ import annotations

import argparse
import csv
import html
import math
from pathlib import Path
from typing import Iterable


def read_scape_matrix(path: Path) -> list[list[float]]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    lines = [line.strip() for line in path.read_text(encoding="utf-8", errors="ignore").splitlines() if line.strip()]
    if not lines:
        return []
    try:
        ncols = int(float(lines[0]))
    except ValueError:
        return []
    values: list[float] = []
    for line in lines[1:]:
        for part in line.replace(",", " ").split():
            try:
                values.append(float(part))
            except ValueError:
                pass
    if ncols <= 0:
        return []
    rows = []
    for i in range(0, len(values) - (len(values) % ncols), ncols):
        rows.append(values[i : i + ncols])
    return rows


def sum_abs(matrix: list[list[float]]) -> float:
    return sum(abs(v) for row in matrix for v in row)


def final_mean(matrix: list[list[float]]) -> float:
    if not matrix:
        return math.nan
    row = matrix[-1]
    return sum(row) / len(row) if row else math.nan


def mean_delta(a: float, b: float) -> float:
    if math.isnan(a) or math.isnan(b):
        return math.nan
    return a - b


def metric_row(exp_dir: Path) -> dict[str, float | str]:
    pot = read_scape_matrix(exp_dir / "SED_TRANS_POT_ANN.txt")
    actual = read_scape_matrix(exp_dir / "SED_TRANS_ANN.txt")
    beach = read_scape_matrix(exp_dir / "VOLUME_B_ANN_AVE.txt")
    shore = read_scape_matrix(exp_dir / "CONTOUR_SHORE.txt")
    rock = read_scape_matrix(exp_dir / "CONTOUR_ROCK.txt")

    pot_total = sum_abs(pot)
    actual_total = sum_abs(actual)
    ratio = actual_total / pot_total if pot_total else math.nan

    return {
        "experiment": exp_dir.name,
        "potential_transport_abs_total": pot_total,
        "actual_transport_abs_total": actual_total,
        "actual_to_potential_ratio": ratio,
        "final_mean_beach_volume": final_mean(beach),
        "final_mean_shore_contour": final_mean(shore),
        "final_mean_rock_contour": final_mean(rock),
    }


def write_csv(path: Path, rows: list[dict[str, float | str]]) -> None:
    if not rows:
        return
    keys = list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def safe_float(value: float | str) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return math.nan
    return v


def write_bar_svg(path: Path, rows: list[dict[str, float | str]], key: str, title: str) -> None:
    data = [(str(row["experiment"]), safe_float(row[key])) for row in rows]
    data = [(name, value) for name, value in data if not math.isnan(value)]
    if not data:
        return

    width = 1200
    left = 270
    right = 40
    top = 55
    bar_h = 20
    gap = 7
    height = top + len(data) * (bar_h + gap) + 45
    max_abs = max(abs(value) for _, value in data) or 1.0
    plot_w = width - left - right
    zero_x = left if all(value >= 0 for _, value in data) else left + plot_w / 2
    scale = (plot_w if all(value >= 0 for _, value in data) else plot_w / 2) / max_abs

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<style>text{font-family:Segoe UI,Arial,sans-serif;font-size:12px;fill:#222}.title{font-size:20px;font-weight:700}.axis{stroke:#777;stroke-width:1}.bar{fill:#2f6f9f}.neg{fill:#b65f4c}.label{font-size:11px;fill:#444}</style>',
        f'<text x="20" y="30" class="title">{html.escape(title)}</text>',
        f'<line x1="{zero_x:.2f}" y1="{top-15}" x2="{zero_x:.2f}" y2="{height-30}" class="axis"/>',
    ]
    for idx, (name, value) in enumerate(data):
        y = top + idx * (bar_h + gap)
        if value >= 0:
            x = zero_x
            w = value * scale
            cls = "bar"
        else:
            w = abs(value) * scale
            x = zero_x - w
            cls = "neg"
        parts.append(f'<text x="20" y="{y+15}" class="label">{html.escape(name)}</text>')
        parts.append(f'<rect x="{x:.2f}" y="{y}" width="{max(w, 1):.2f}" height="{bar_h}" class="{cls}"/>')
        parts.append(f'<text x="{min(width-right-80, max(left, x+w+5)):.2f}" y="{y+15}" class="label">{value:.4g}</text>')
    parts.append("</svg>")
    path.write_text("\n".join(parts), encoding="utf-8")


def add_baseline_deltas(rows: list[dict[str, float | str]], baseline: str) -> None:
    base = next((row for row in rows if row["experiment"] == baseline), None)
    if base is None:
        return
    for row in rows:
        for key in (
            "potential_transport_abs_total",
            "actual_transport_abs_total",
            "actual_to_potential_ratio",
            "final_mean_beach_volume",
            "final_mean_shore_contour",
            "final_mean_rock_contour",
        ):
            row[f"delta_vs_{baseline}_{key}"] = mean_delta(safe_float(row[key]), safe_float(base[key]))


def experiment_dirs(output_root: Path, skip: Iterable[str]) -> list[Path]:
    skip_set = set(skip)
    return sorted([p for p in output_root.iterdir() if p.is_dir() and p.name not in skip_set], key=lambda p: p.name)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--analysis-root", required=True)
    parser.add_argument("--baseline", default="ST00_BASE_CONTROL")
    parser.add_argument("--skip-directory", action="append", default=[])
    args = parser.parse_args()

    output_root = Path(args.output_root)
    analysis_root = Path(args.analysis_root)
    analysis_root.mkdir(parents=True, exist_ok=True)

    rows = [metric_row(exp_dir) for exp_dir in experiment_dirs(output_root, args.skip_directory)]
    add_baseline_deltas(rows, args.baseline)
    write_csv(analysis_root / "scape_quick_metrics.csv", rows)

    charts = [
        ("potential_transport_abs_total", "Potential transport total abs"),
        ("actual_transport_abs_total", "Actual transport total abs"),
        ("actual_to_potential_ratio", "Actual / potential transport ratio"),
        (f"delta_vs_{args.baseline}_final_mean_beach_volume", f"Final mean beach volume delta vs {args.baseline}"),
        (f"delta_vs_{args.baseline}_final_mean_shore_contour", f"Final mean shore contour delta vs {args.baseline}"),
        (f"delta_vs_{args.baseline}_final_mean_rock_contour", f"Final mean rock contour delta vs {args.baseline}"),
    ]
    for key, title in charts:
        if rows and key in rows[0]:
            write_bar_svg(analysis_root / f"{key}.svg", rows, key, title)

    print(f"Wrote {len(rows)} experiment metrics to {analysis_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

